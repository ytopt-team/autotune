rm -r tmp* yt* res* 
rm *t1 power* *.o
